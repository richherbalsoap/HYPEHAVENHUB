"""
Admin panel views for the store
"""
import json
import base64
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Q, Sum, Count, F
from django.utils import timezone
from datetime import timedelta

from .models import (
    User, Product, Order, Complaint, Category, Brand,
    AdminDashboardStats, Payment, OrderItem, Review, OrderTracking, ProductImage, ProductPrice, CountrySetting, LANGUAGE_CHOICES
)
from .forms import (
    ProductForm, AdminComplaintForm, ComplaintForm, AdminOrderUpdateForm
)


def admin_required(function):
    """Decorator to check if user is admin"""
    def wrap(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_staff:
            messages.error(request, 'Admin access required')
            return redirect('login')
        return function(request, *args, **kwargs)
    return wrap


@login_required
@admin_required
def admin_dashboard(request):
    """Admin dashboard with statistics"""
    today = timezone.now().date()
    stats, created = AdminDashboardStats.objects.get_or_create(date=today)
    
    # Calculate statistics
    total_orders = Order.objects.count()
    total_revenue = Order.objects.aggregate(Sum('grand_total'))['grand_total__sum'] or 0
    total_users = User.objects.filter(is_staff=False).count()
    new_orders_today = Order.objects.filter(created_at__date=today).count()
    total_products = Product.objects.count()
    returned_orders = Order.objects.filter(status='returned').count()
    total_complaints = Complaint.objects.count()
    open_complaints = Complaint.objects.filter(status__in=['open', 'in_progress']).count()
    pending_orders = Order.objects.filter(status__in=['pending', 'confirmed', 'processing']).count()
    paid_orders = Payment.objects.filter(status='success').count()
    unpaid_orders = Payment.objects.filter(status='pending').count()
    today_revenue = Order.objects.filter(created_at__date=today).aggregate(Sum('grand_total'))['grand_total__sum'] or 0
    
    # Update stats
    stats.total_orders = total_orders
    stats.total_revenue = today_revenue
    stats.total_users = total_users
    stats.new_orders_today = new_orders_today
    stats.total_products = total_products
    stats.returned_orders = returned_orders
    stats.total_complaints = total_complaints
    stats.open_complaints = open_complaints
    stats.save()
    
    # Recent orders
    recent_orders = Order.objects.select_related('user', 'address', 'payment').order_by('-created_at')[:10]
    
    # Recent complaints
    recent_complaints = Complaint.objects.select_related('user').order_by('-created_at')[:5]
    
    context = {
        'stats': stats,
        'recent_orders': recent_orders,
        'recent_complaints': recent_complaints,
        'total_orders': total_orders,
        'total_revenue': total_revenue,
        'total_users': total_users,
        'new_orders_today': new_orders_today,
        'total_products': total_products,
        'returned_orders': returned_orders,
        'pending_orders': pending_orders,
        'paid_orders': paid_orders,
        'unpaid_orders': unpaid_orders,
        'today_revenue': today_revenue,
    }
    return render(request, 'admin/dashboard.html', context)


@login_required
@admin_required
def admin_products(request):
    """Manage products"""
    products = Product.objects.select_related('brand', 'category').order_by('-created_at')
    



    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        products = products.filter(
            Q(name__icontains=search_query) | 
            Q(description__icontains=search_query)
        )
    
    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(products, 20)
    page = request.GET.get('page', 1)
    products = paginator.get_page(page)
    
    context = {
        'products': products,
        'search_query': search_query,
    }
    return render(request, 'admin/products_list.html', context)


@login_required
@admin_required
def admin_product_create(request):
    """Create new product"""
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save()

            if 'video_upload' in request.FILES:
                from .storage import upload_file
                try:
                    product.video_url = upload_file(request.FILES['video_upload'], folder="videos")
                    product.save()
                except Exception as e:
                    messages.error(request, f"Video upload failed: {e}")

            # Save uploaded images directly to Vercel Blob
            images = request.FILES.getlist('multiple_images')
            for i, img in enumerate(images):
                from .storage import upload_file
                try:
                    url = upload_file(img, folder="products")
                    ProductImage.objects.create(
                        product=product,
                        image_url=url,
                        is_primary=(i == 0)
                    )
                except Exception as e:
                    messages.error(request, f"Image upload failed: {e}")

            messages.success(request, 'Product created successfully!')
            return redirect('admin_products')
    else:
        form = ProductForm()

    context = {'form': form, 'title': 'Add New Product'}
    return render(request, 'admin/product_form.html', context)


@login_required
@admin_required
def admin_product_edit(request, pk):
    """Edit product"""
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            product = form.save()

            if 'video_upload' in request.FILES:
                from .storage import upload_file
                try:
                    product.video_url = upload_file(request.FILES['video_upload'], folder="videos")
                    product.save()
                except Exception as e:
                    messages.error(request, f"Video upload failed: {e}")

            # Save newly uploaded images directly to Vercel Blob
            images = request.FILES.getlist('multiple_images')
            for img in images:
                from .storage import upload_file
                try:
                    url = upload_file(img, folder="products")
                    has_primary = product.images.filter(is_primary=True).exists()
                    ProductImage.objects.create(
                        product=product,
                        image_url=url,
                        is_primary=not has_primary
                    )
                except Exception as e:
                    messages.error(request, f"Image upload failed: {e}")

            messages.success(request, 'Product updated successfully!')
            return redirect('admin_products')
    else:
        form = ProductForm(instance=product)

    context = {'form': form, 'title': 'Edit Product', 'product': product}
    return render(request, 'admin/product_form.html', context)


@login_required
@admin_required
def admin_product_delete(request, pk):
    """Delete product"""
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        messages.success(request, 'Product deleted successfully!')
        return redirect('admin_products')

    context = {'product': product}
    return render(request, 'admin/product_confirm_delete.html', context)


@login_required
@admin_required
def admin_product_image_delete(request, pk):
    """Delete a product image"""
    image = get_object_or_404(ProductImage, pk=pk)
    product_pk = image.product.pk
    image.delete()
    return JsonResponse({'success': True, 'message': 'Image deleted successfully'})


@login_required
@admin_required
def admin_product_prices(request, pk):
    """Manage country specific prices for a product"""
    product = get_object_or_404(Product, pk=pk)
    
    if request.method == 'POST':
        country_id = request.POST.get('country_id')
        price = request.POST.get('price')
        
        if country_id and price:
            country = get_object_or_404(CountrySetting, pk=country_id)
            ProductPrice.objects.update_or_create(
                product=product,
                country=country,
                defaults={'price': price}
            )
            messages.success(request, f'Price for {country.name} updated.')
        
        delete_id = request.POST.get('delete_price_id')
        if delete_id:
            ProductPrice.objects.filter(id=delete_id, product=product).delete()
            messages.success(request, 'Price removed.')
            
        return redirect('admin_product_prices', pk=pk)
        
    prices = product.country_prices.all()
    all_countries = CountrySetting.objects.all().order_by('name')
    context = {
        'product': product, 
        'prices': prices, 
        'all_countries': all_countries,
        'title': f'Manage Prices: {product.name}'
    }
    return render(request, 'admin/product_prices.html', context)


@login_required
@admin_required
def admin_orders(request):
    """View all orders"""
    orders = Order.objects.select_related('user', 'address', 'payment').prefetch_related('items').order_by('-created_at')
    
    # Filter by status
    status = request.GET.get('status', '')
    if status:
        orders = orders.filter(status=status)

    payment_status = request.GET.get('payment_status', '')
    if payment_status:
        orders = orders.filter(payment__status=payment_status)
    
    # Search
    search_query = request.GET.get('search', '')
    if search_query:
        orders = orders.filter(
            Q(order_id__icontains=search_query) |
            Q(user__email__icontains=search_query) |
            Q(user__first_name__icontains=search_query) |
            Q(user__last_name__icontains=search_query) |
            Q(address__phone__icontains=search_query)
        )
    
    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(orders, 20)
    page = request.GET.get('page', 1)
    orders = paginator.get_page(page)
    
    context = {
        'orders': orders,
        'status_list': Order.STATUS_CHOICES,
        'payment_status_list': Payment.STATUS_CHOICES,
        'selected_status': status,
        'selected_payment_status': payment_status,
        'search_query': search_query,
    }
    return render(request, 'admin/orders_list.html', context)


@login_required
@admin_required
def admin_order_detail(request, order_id):
    """View and update a customer's full order lifecycle."""
    order = get_object_or_404(
        Order.objects.select_related('user', 'address', 'payment', 'coupon')
        .prefetch_related('items__product', 'tracking', 'complaints'),
        order_id=order_id,
    )
    payment = getattr(order, 'payment', None)
    old_status = order.status
    old_payment_status = payment.status if payment else ''

    if request.method == 'POST':
        form = AdminOrderUpdateForm(request.POST, instance=order, payment=payment)
        if form.is_valid():
            order = form.save()
            payment_method = form.cleaned_data['payment_method']
            payment_status = form.cleaned_data['payment_status']
            payment, _ = Payment.objects.get_or_create(
                order=order,
                defaults={
                    'method': payment_method,
                    'status': payment_status,
                    'amount': order.grand_total,
                }
            )
            payment.method = payment_method
            payment.status = payment_status
            payment.amount = order.grand_total
            payment.save()

            tracking_note = form.cleaned_data.get('tracking_note', '').strip()
            if order.status != old_status or tracking_note:
                description = tracking_note or f"Order status updated to {order.get_status_display()}."
                OrderTracking.objects.create(
                    order=order,
                    status=order.status,
                    description=description,
                )

            if payment.status != old_payment_status:
                OrderTracking.objects.create(
                    order=order,
                    status=f"payment_{payment.status}",
                    description=f"Payment marked as {payment.get_status_display()}.",
                )

            messages.success(request, f"Order {order.order_id} updated successfully.")
            return redirect('admin_order_detail', order_id=order.order_id)
    else:
        form = AdminOrderUpdateForm(instance=order, payment=payment)

    context = {
        'order': order,
        'payment': getattr(order, 'payment', None),
        'items': order.items.select_related('product', 'variant').all(),
        'tracking': order.tracking.all(),
        'complaints': order.complaints.select_related('user').all(),
        'form': form,
    }
    return render(request, 'admin/order_detail.html', context)


@login_required
@admin_required
def admin_complaints(request):
    """Manage complaints"""
    complaints = Complaint.objects.select_related('user', 'order').order_by('-created_at')
    
    # Filter by status
    status = request.GET.get('status', '')
    if status:
        complaints = complaints.filter(status=status)
    
    # Filter by priority
    priority = request.GET.get('priority', '')
    if priority:
        complaints = complaints.filter(priority=priority)
    
    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(complaints, 20)
    page = request.GET.get('page', 1)
    complaints = paginator.get_page(page)
    
    context = {
        'complaints': complaints,
        'status_list': Complaint.STATUS_CHOICES,
        'priority_list': [('low', 'Low'), ('medium', 'Medium'), ('high', 'High')],
        'selected_status': status,
        'selected_priority': priority,
    }
    return render(request, 'admin/complaints_list.html', context)


@login_required
@admin_required
def admin_complaint_detail(request, complaint_id):
    """View and respond to complaint"""
    complaint = get_object_or_404(Complaint, complaint_id=complaint_id)
    
    if request.method == 'POST':
        form = AdminComplaintForm(request.POST, instance=complaint)
        if form.is_valid():
            updated = form.save(commit=False)
            if updated.status in ['resolved', 'closed'] and not updated.resolved_at:
                updated.resolved_at = timezone.now()
            elif updated.status not in ['resolved', 'closed']:
                updated.resolved_at = None
            updated.save()
            form.save_m2m()
            messages.success(request, 'Complaint updated successfully!')
            return redirect('admin_complaints')
    else:
        form = AdminComplaintForm(instance=complaint)
    
    context = {
        'complaint': complaint,
        'form': form,
    }
    return render(request, 'admin/complaint_detail.html', context)


@login_required
@admin_required
def admin_reports(request):
    """Analytics and reports"""
    # Get date range
    days = request.GET.get('days', 30)
    try:
        days = int(days)
    except ValueError:
        days = 30
    
    start_date = timezone.now().date() - timedelta(days=days)
    
    # Sales data
    orders = Order.objects.filter(created_at__date__gte=start_date)
    total_sales = orders.aggregate(Sum('grand_total'))['grand_total__sum'] or 0
    total_orders = orders.count()
    avg_order_value = total_sales / total_orders if total_orders > 0 else 0
    
    # Product performance
    product_sales = OrderItem.objects.filter(
        order__created_at__date__gte=start_date
    ).values('product__name').annotate(
        total_sold=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).order_by('-total_revenue')[:10]
    
    # Return rate
    returned_orders = Order.objects.filter(
        status='returned',
        created_at__date__gte=start_date
    ).count()
    return_rate = (returned_orders / total_orders * 100) if total_orders > 0 else 0
    
    # Category performance
    category_sales = OrderItem.objects.filter(
        order__created_at__date__gte=start_date
    ).values('product__category__name').annotate(
        total_sold=Sum('quantity'),
        total_revenue=Sum('total_price')
    ).order_by('-total_revenue')
    
    # Daily sales trend
    daily_sales_query = Order.objects.filter(
        created_at__date__gte=start_date
    ).extra(
        select={'date': 'DATE(created_at)'}
    ).values('date').annotate(
        revenue=Sum('grand_total'),
        order_count=Count('id')
    ).order_by('date')
    daily_sales = []
    for day in daily_sales_query:
        order_count = day['order_count'] or 0
        revenue = day['revenue'] or 0
        day['avg_order_value'] = revenue / order_count if order_count else 0
        daily_sales.append(day)
    
    context = {
        'total_sales': total_sales,
        'total_orders': total_orders,
        'avg_order_value': avg_order_value,
        'returned_orders': returned_orders,
        'return_rate': return_rate,
        'product_sales': product_sales,
        'category_sales': category_sales,
        'daily_sales': daily_sales,
        'days': days,
    }
    return render(request, 'admin/reports.html', context)


@login_required
def submit_complaint(request):
    """User complaint submission"""
    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.user = request.user
            complaint.save()
            messages.success(request, 'Your complaint has been submitted successfully!')
            return redirect('complaint_detail', complaint_id=complaint.complaint_id)
    else:
        form = ComplaintForm()
    
    # Get user's orders for the complaint form
    user_orders = Order.objects.filter(user=request.user).order_by('-created_at')
    
    context = {
        'form': form,
        'user_orders': user_orders,
    }
    return render(request, 'store/complaint_form.html', context)


@login_required
def complaint_detail(request, complaint_id):
    """View complaint status"""
    complaint = get_object_or_404(Complaint, complaint_id=complaint_id, user=request.user)
    context = {'complaint': complaint}
    return render(request, 'store/complaint_detail.html', context)


@login_required
def user_complaints(request):
    """List user's complaints"""
    complaints = Complaint.objects.filter(user=request.user).order_by('-created_at')
    
    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(complaints, 10)
    page = request.GET.get('page', 1)
    complaints = paginator.get_page(page)
    
    context = {'complaints': complaints}
    return render(request, 'store/complaints_list.html', context)

@login_required
def admin_countries(request):
    """List all country settings"""
    if not request.user.is_staff:
        messages.error(request, 'Access denied.')
        return redirect('home')
        
    countries = CountrySetting.objects.all().order_by('name')
    return render(request, 'admin/countries_list.html', {
        'countries': countries,
        'title': 'Country Settings'
    })

@login_required
def admin_country_create(request):
    """Create new country setting"""
    if not request.user.is_staff:
        return redirect('home')
        
    if request.method == 'POST':
        name = request.POST.get('name')
        code = request.POST.get('code')
        currency_code = request.POST.get('currency_code')
        currency_symbol = request.POST.get('currency_symbol')
        default_language = request.POST.get('default_language')
        shipping_charge = request.POST.get('shipping_charge')

        valid_lang_codes = {code for code, _ in LANGUAGE_CHOICES}
        if default_language not in valid_lang_codes:
            messages.error(request, 'Please select a valid language from the dropdown.')
            return render(request, 'admin/country_form.html', {
                'title': 'Add Country Setting',
                'language_choices': LANGUAGE_CHOICES,
            })

        try:
            CountrySetting.objects.create(
                name=name,
                code=code,
                currency_code=currency_code,
                currency_symbol=currency_symbol,
                default_language=default_language,
                shipping_charge=shipping_charge
            )
            messages.success(request, 'Country added successfully!')
            return redirect('admin_countries')
        except Exception as e:
            messages.error(request, f'Error adding country: {str(e)}')
            
    return render(request, 'admin/country_form.html', {
        'title': 'Add Country Setting',
        'language_choices': LANGUAGE_CHOICES,
    })

@login_required
def admin_country_edit(request, pk):
    """Edit country setting"""
    if not request.user.is_staff:
        return redirect('home')
        
    country = get_object_or_404(CountrySetting, pk=pk)
    
    if request.method == 'POST':
        default_language = request.POST.get('default_language')
        valid_lang_codes = {code for code, _ in LANGUAGE_CHOICES}
        if default_language not in valid_lang_codes:
            messages.error(request, 'Please select a valid language from the dropdown.')
            return render(request, 'admin/country_form.html', {
                'country': country,
                'title': f'Edit {country.name}',
                'language_choices': LANGUAGE_CHOICES,
            })

        country.name = request.POST.get('name')
        country.code = request.POST.get('code')
        country.currency_code = request.POST.get('currency_code')
        country.currency_symbol = request.POST.get('currency_symbol')
        country.default_language = default_language
        country.shipping_charge = request.POST.get('shipping_charge')
        
        try:
            country.save()
            messages.success(request, 'Country updated successfully!')
            return redirect('admin_countries')
        except Exception as e:
            messages.error(request, f'Error updating country: {str(e)}')
            
    return render(request, 'admin/country_form.html', {
        'country': country,
        'title': f'Edit {country.name}',
        'language_choices': LANGUAGE_CHOICES,
    })

@login_required
def admin_country_delete(request, pk):
    """Delete country setting"""
    if not request.user.is_staff:
        return redirect('home')
        
    country = get_object_or_404(CountrySetting, pk=pk)
    if request.method == 'POST':
        country.delete()
        messages.success(request, 'Country removed.')
    return redirect('admin_countries')

